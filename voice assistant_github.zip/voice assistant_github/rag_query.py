import json
import faiss
import numpy as np
import time
from sentence_transformers import SentenceTransformer

from hf_stt import listen
from hf_tts import speak

# -------------------------
# Load data
# -------------------------
with open("shopify_data.json", "r", encoding="utf-8") as f:
    data = json.load(f)

texts = [item["content"] for item in data]

# -------------------------
# Load FAISS index
# -------------------------
index = faiss.read_index("faiss.index")

# -------------------------
# Load embedding model
# -------------------------
model = SentenceTransformer("all-MiniLM-L6-v2")

# -------------------------
# Start (TEXT ONLY greeting — important)
# -------------------------
welcome=" Shopify Voice Assistant started. Speak your question."
speak(welcome)

while True:
    # 1️⃣ LISTEN (mic only here)
    question = listen()

    if not question:
        continue

    question = question.lower()
    print("User:", question)

    # EXIT
    if "exit" in question or "stop" in question:
        speak("Goodbye. Have a nice day.")
        break

    # -------------------------
    # LIST PRODUCTS
    # -------------------------
    if (
        "what are the products" in question
        or "products available" in question
        or "list products" in question
        or "what do you sell" in question
    ):
        answer = "Here are the available products."
        print(answer)
        speak(answer)

        for item in data:
            if item.get("type") == "product":
                speak(item.get("title"))

        continue

    # -------------------------
    # FAISS SEARCH
    # -------------------------
    query_embedding = model.encode([question])
    _, I = index.search(np.array(query_embedding), k=1)
    best_match = texts[I[0][0]]

    # -------------------------
    # INTENT ANSWER
    # -------------------------
    answer = ""

    if "price" in question:
        for line in best_match.splitlines():
            if "price" in line.lower():
                answer = line
                break

    elif "size" in question:
        for line in best_match.splitlines():
            if "size" in line.lower():
                answer = line
                break

    else:
        answer = best_match

    # 3️⃣ SPEAK (mic is NOT active here)
    print("Answer:", answer)
    speak(answer)

    # 4️⃣ Small pause before next listen
    time.sleep(0.5)
