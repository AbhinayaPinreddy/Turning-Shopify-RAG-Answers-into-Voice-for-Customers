import speech_recognition as sr

def test_stt():
    r = sr.Recognizer()

    with sr.Microphone() as source:
        print("🎤 Say something...")
        r.adjust_for_ambient_noise(source, duration=1)
        audio = r.listen(source)

    try:
        text = r.recognize_google(audio)
        print("✅ STT working!")
        print("🗣 You said:", text)
    except sr.UnknownValueError:
        print("❌ Could not understand audio")
    except sr.RequestError as e:
        print("❌ STT request error:", e)

if __name__ == "__main__":
    test_stt()
