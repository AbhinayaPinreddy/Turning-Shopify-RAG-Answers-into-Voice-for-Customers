import json
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

# -------------------------
# Load Shopify data
# -------------------------
with open("shopify_data.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# Extract text chunks (ONLY content is embedded)
texts = [item["content"] for item in data if item.get("content")]

print(f"Total chunks: {len(texts)}")

# -------------------------
# Load embedding model (FREE)
# -------------------------
model = SentenceTransformer("all-MiniLM-L6-v2")

print(" Creating embeddings...")
embeddings = model.encode(texts, show_progress_bar=True)

# -------------------------
# Build FAISS index
# -------------------------
dimension = embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(np.array(embeddings))

# -------------------------
# Save FAISS index
# -------------------------
faiss.write_index(index, "faiss.index")

print("FAISS index created successfully")
print("Total vectors:", index.ntotal)
