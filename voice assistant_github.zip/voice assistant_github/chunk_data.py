import json

CHUNK_SIZE = 300  # characters

def chunk_text(text, size=CHUNK_SIZE):
    chunks = []
    start = 0
    while start < len(text):
        chunks.append(text[start:start + size])
        start += size
    return chunks

# Load Shopify data
with open("shopify_data.json", "r", encoding="utf-8") as f:
    data = json.load(f)

chunks = []

for item in data:
    text_chunks = chunk_text(item["content"])
    for chunk in text_chunks:
        chunks.append({
            "type": item["type"],
            "title": item["title"],
            "content": chunk
        })

# Save chunks
with open("rag_chunks.json", "w", encoding="utf-8") as f:
    json.dump(chunks, f, ensure_ascii=False, indent=2)

print(" Chunking complete")
print("Total chunks:", len(chunks))
