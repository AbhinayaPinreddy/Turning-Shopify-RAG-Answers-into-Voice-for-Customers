from hf_tts import speak

if __name__ == "__main__":
    print("Testing TTS...")
    speak("Hello Abhinaya. Your text to speech system is working correctly.")
